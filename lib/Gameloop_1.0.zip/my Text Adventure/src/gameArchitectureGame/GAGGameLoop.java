package gameArchitectureGame;

import at.fhooe.im440.ladar.loop.GameLoop;
import at.fhooe.im440.ladar.task.Task;

public class GAGGameLoop implements GameLoop {
	
	final double TARGET_FPS = 60;
	final double TARGET_TIME_BETWEEN_UPDATES = 1000000000 / TARGET_FPS;
	
	@Override
	public void loop(Task task) {

		double now;
		boolean isFinished = false;
		
		// init task stuff
		task.initialize();
		
		while (!isFinished)
		{
			now = System.nanoTime();

			// execute task stuff
			isFinished = task.execute();
			
			if(System.nanoTime() - now < TARGET_TIME_BETWEEN_UPDATES)
			{
				try {
					Thread.sleep(1);
				} 
				catch(Exception e) {
					e.printStackTrace();
				}
			}
		}

		// cleanup task stuff
		task.cleanup();
		
	}

}
