package gameArchitectureGame;

import at.fhooe.im440.ladar.loop.GameLoop;
import at.fhooe.im440.ladar.loop.GameLoopFactory;

public class GAGGameLoopFactory implements GameLoopFactory {

	@Override
	public GameLoop create() {
		return new GAGGameLoop();
	}

}
